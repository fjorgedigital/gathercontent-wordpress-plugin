<?php
namespace GatherContent\Importer\Sync;

class Async_Push_Action extends Async_Base {
	protected $action = 'gc_push_items';
}
