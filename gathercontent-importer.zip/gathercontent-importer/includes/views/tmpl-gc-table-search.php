<input class="alignleft" type="search" id="gc-search-input" value="" placeholder="<?php esc_html_e( 'Filter Items...', 'gathercontent-import' ); ?>">
