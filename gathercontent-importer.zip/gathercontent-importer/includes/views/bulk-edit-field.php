<div style="display:none;">
	<?php $this->output( 'refresh_link' ); ?>
</div>
<p class="submit inline-edit-save">
	<button id="gc-sync-modal" type="button" class="button gc-button-primary alignright"><?php esc_html_e( 'GatherContent Sync', 'gathercontent-importer' ); ?></button>
</p>
