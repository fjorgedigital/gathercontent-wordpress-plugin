<div class="notice error">
	<p><?php esc_html_e( 'Uh oh! We couldn\'t find a Template and/or Project. It\'s possible you don\'t have access to the project in GatherContent, or the GatherContent API is having issues.', 'gathercontent-import' ); ?></p>
</div>
