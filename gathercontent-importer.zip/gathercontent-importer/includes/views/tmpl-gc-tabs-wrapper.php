<div class="gc-template-tab-group">
	<h5 class="nav-tab-wrapper gc-nav-tab-wrapper gc-nav-tab-wrapper-bb"></h5>
	<p><a class="nav-tab-link link-to-mapping-defaults" href="#mapping-defaults"><?php _e( 'Set Mapping Defaults', 'gathercontent-import' ); ?></a></p>
</div>
